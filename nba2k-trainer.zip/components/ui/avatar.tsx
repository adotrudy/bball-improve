export const Avatar = ({ children }) => <div>{children}</div>;
export const AvatarImage = ({ src, alt }) => <img src={src} alt={alt} className='w-16 h-16 rounded-full' />;